﻿using System;

namespace WebApplication9
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (TextBox1.Text == "admin" && TextBox2.Text == "T4TEQ123")
                {
                    Response.Redirect("Admin_page.aspx");
                }
            else
                {
                    Response.Write("<script>alert('Invalid Log In')</script>");
                    TextBox1.Text = "";
                    TextBox2.Text = "";
                }
        }
    }
}