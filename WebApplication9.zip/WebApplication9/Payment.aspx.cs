﻿using iTextSharp.text;
using System;
using System.Data.SqlClient;
using System.Web;
using System.Web.UI;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.IO;
namespace WebApplication9

{

    public partial class WebForm5 : System.Web.UI.Page
    {
        SqlConnection cx = new SqlConnection("Data Source=DESKTOP-PFMCCVN\\VE_SERVER;Initial Catalog=krish;Integrated Security=True;Pooling=False");
        SqlDataReader dr;
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                cx.Open();
                SqlCommand cmd = new SqlCommand("select rgid from adminpage order by rgid desc", cx);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DropDownList2.Items.Add(dr[0].ToString());

                }
                cx.Close();
            }
        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {
            cx.Open();
            SqlCommand cmd = new SqlCommand("select tfees from adminpage where rgid='"+DropDownList2.SelectedValue+"' ", cx);
            dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                TextBox1.Text = dr.GetInt32(0).ToString();
            }
            cx.Close();
        }

        protected void TextBox3_TextChanged(object sender, EventArgs e)
        { 
            TextBox2.Text = (Convert.ToInt16(TextBox2.Text) + Convert.ToInt16(TextBox3.Text)).ToString();
        }
        public void excute()
        {
            string b = (Convert.ToInt16(TextBox1.Text) - Convert.ToInt16(TextBox2.Text)).ToString();
            SqlCommand cmd = new SqlCommand("insert into paymentpage(rid,fee,paidamount,balance,modeofpay) values('" + DropDownList2.SelectedValue + "','" + TextBox1.Text + "','" + TextBox2.Text + "','"+b+"','"+DropDownList3.SelectedValue+"')", cx);
            cmd.ExecuteNonQuery();
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            cx.Open();
            excute();
            cx.Close();
            Response.Redirect("Payment.aspx");
        }
        protected void Button3_Click(object sender, EventArgs e)
        {
            cx.Open();
            SqlCommand cmd = new SqlCommand("update paymentpage set paidamount='"+TextBox2.Text+"',balance='"+(Convert.ToInt32(TextBox1.Text)-Convert.ToInt32(TextBox2.Text)).ToString()+"',modeofpay='"+DropDownList3.SelectedValue+"' where rid='"+DropDownList2.SelectedValue+"'", cx);
            cmd.ExecuteNonQuery();
            cx.Close();
            Response.Redirect("Manual.aspx");
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.ContentType = "Application/pdf";
            Response.AddHeader("Content-Disposition", "attachment;filename=YourFileName.pdf");
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            StringWriter cs = new StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(cs);
            DivToprint.RenderControl(hw);
            Document doc = new Document(PageSize.A4,50f,50f,30f,30f);
            HTMLWorker htw = new HTMLWorker(doc);
            PdfWriter.GetInstance(doc, Response.OutputStream);
            doc.Open();
            StringReader sr = new StringReader(cs.ToString());
            htw.Parse(sr);
            doc.Close();
            Response.Write(doc);
            Response.End();
        }
        public override void VerifyRenderingInServerForm(Control control)
        {
            
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            cx.Open();
            SqlCommand cmd = new SqlCommand("select * from paymentpage where rid='" + DropDownList2.SelectedValue + "'", cx);
            dr=cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                DropDownList2.SelectedValue = dr.GetInt32(1).ToString();
                TextBox1.Text = dr.GetInt32(2).ToString();
                TextBox2.Text = dr.GetInt32(3).ToString();
                TextBox3.Text = dr.GetInt32(3).ToString();
                DropDownList3.SelectedValue = dr[5].ToString();
            }
            cx.Close();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            cx.Open();
            SqlCommand cmd = new SqlCommand("select * from paymentpage where rid='" + DropDownList2.SelectedValue + "'", cx);
            dr = cmd.ExecuteReader();
            GridView1.DataSource = dr;
            GridView1.DataBind();
            cx.Close();
        }

        protected void GridView2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void DropDownList3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}