﻿using System;
using System.Data.SqlClient;

namespace WebApplication9
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        SqlConnection cx = new SqlConnection("Data Source=DESKTOP-PFMCCVN\\VE_SERVER;Initial Catalog=krish;Integrated Security=True;Pooling=False");
        SqlDataReader dr;
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
                cx.Open();
                SqlCommand cmd = new SqlCommand("select form_no from student order by form_no desc", cx);
                dr = cmd.ExecuteReader();
                while (dr.Read())
                {
                    DropDownList1.Items.Add(dr[0].ToString());

                }
                cx.Close();
            }
        }
        
        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            cx.Open();
            SqlCommand cmd = new SqlCommand("select sname,courses,whatsapp,batch from student where form_no='"+DropDownList1.SelectedValue+"'", cx);
            dr = cmd.ExecuteReader();
            GridView1.DataSource = dr;
            GridView1.DataBind();
            cx.Close();
        }
        protected void Button3_Click(object sender, EventArgs e)
        {
            int z = Convert.ToInt16(TextBox3.Text);
            int x;
            int d;
            if (TextBox1.Text == "")
            {
                TextBox1.Text = TextBox2.Text;
            }
            else
            {
                TextBox1.Text += "," + TextBox2.Text;
            }
            cx.Open();
            SqlCommand cmd = new SqlCommand("select fees,discount from details where coursename='" + TextBox2.Text + "'", cx);
            dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                dr.Read();
                x = dr.GetInt32(0);
                d = dr.GetInt32(1);
                z += (x - (x * d) / 100);
            }
            TextBox3.Text = z.ToString();
            TextBox2.Text = "";
            cx.Close();
        }
        public void excute()
        {
            SqlCommand cmd = new SqlCommand("insert into adminpage(courses,tfees) values('" + TextBox1.Text + "','" + TextBox3.Text + "')", cx);
            cmd.ExecuteNonQuery();
        }
        protected void Button4_Click1(object sender, EventArgs e)
        {
            cx.Open();
            excute();
            cx.Close();
            Response.Redirect("Payment.aspx");
        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}