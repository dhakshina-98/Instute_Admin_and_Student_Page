﻿using System;
using System.Data.SqlClient;

namespace WebApplication9
{
    public partial class WebForm6 : System.Web.UI.Page
    {

        SqlConnection cx = new SqlConnection("Data Source=DESKTOP-PFMCCVN\\VE_SERVER;Initial Catalog=krish;Integrated Security=True;Pooling=False");
        SqlDataReader dr;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {
            cx.Open();
            SqlCommand cmd = new SqlCommand("select rgid,courses from adminpage where rgid='" + TextBox1.Text + "'", cx);
            dr = cmd.ExecuteReader();
            GridView1.DataSource = dr;
            GridView1.DataBind();
            cx.Close();
        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            cx.Open();
            SqlCommand cmd = new SqlCommand("insert into manual(rid,mcourse,issuedby) values('" + TextBox1.Text + "','" + TextBox2.Text + "','" + TextBox3.Text + "')", cx);
            cmd.ExecuteNonQuery();
            cx.Close();
            Response.Redirect("Manual.aspx");

        }
    }
}